
#include <math.h>

typedef struct {
  double x;
  double y;
  double z;
  double w;
} Vector;

