var example = require("example");

console.log("My magic number is: ", example.magicNumber());
